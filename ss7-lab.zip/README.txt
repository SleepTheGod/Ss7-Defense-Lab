SS7 + SIP Defense Lab Package
=============================
Files included:
- ss7-full-lab.sh         (main zero-touch installer)
- /etc/suricata/rules/ss7-advanced.rules (Suricata rules)
- /opt/ss7-lab/zeek/ss7-detect.zeek      (Zeek script)
- Vagrantfile            (to spin a VM and auto-run installer)
- README.txt             (this file)

Usage:
1) Copy 'ss7-full-lab.sh' to /root on a fresh Debian 12 VM and run:
   sudo bash /root/ss7-full-lab.sh
2) To use Vagrant: put this entire package in a repo root with Vagrant installed and run 'vagrant up'.
3) Suricata rules are included; the installer attempts to place them under /etc/suricata/rules.
4) Zeek script is included; installer will not overwrite your Zeek install location -- copy to your Zeek site dir if installed.

WARNING: Use only on isolated/test hosts you control. Made by Taylor Christian Newsome
